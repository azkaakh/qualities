<div class="page-sidebar" id="sidebar">
                <!-- Page Sidebar Header-->
                
                <!-- /Page Sidebar Header -->
                <!-- Sidebar Menu -->
                <ul class="nav sidebar-menu">
                    <!--Dashboard-->
                    <li>
                        <a href="<?php echo base_url(); ?>admin/backhome">
                            <i class="menu-icon glyphicon glyphicon-home"></i>
                            <span class="menu-text"> Back To Home </span>
                        </a>
                    </li>
                    <!--Databoxes-->
                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Kelola Project </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>admin/suntingpro">
                                    <span class="menu-text">Sunting Project</span>
                                </a>
                            </li>

                            <!-- <li>
                                <a href="#">
                                    <span class="menu-text">Hapus Project</span>
                                </a>
                            </li>   -->                          
                        </ul>
                    </li>

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Identifikasi Material </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>idenmat/hullcon">
                                    <span class="menu-text">Hull Construction</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>idenmat/machout">
                                    <span class="menu-text">Machinery Outfitting</span>
                                </a>
                            </li>                            
                            <li>
                                <a href="<?php echo base_url(); ?>idenmat/hullout">
                                    <span class="menu-text">Hull Outfitting</span>
                                </a>
                            </li>   
                            <li>
                                <a href="<?php echo base_url(); ?>idenmat/elecout">
                                    <span class="menu-text">Electrical Outfitting</span>
                                </a>
                            </li>   
                            <li>
                                <a href="<?php echo base_url(); ?>idenmat/lihatlist">
                                    <span class="menu-text">Lihat List</span>
                                </a>
                            </li>   
                        </ul>
                    </li>        
                    
                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Fabrikasi </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>fabrikasi/tambahfabrikasi">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>fabrikasi/lihatfabrikasi">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li>  


                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Assembly </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>assembly/tambahassembly">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>assembly/lihatassembly">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li>  

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Erection </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>erection/tambaherection">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>erection/lihaterection">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li>  

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Outfitting </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>outfitting/tambahoutfitting">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>outfitting/lihatoutfitting">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li>  

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Launching </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>launching/tambahlaunching">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>launching/lihatlaunching">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li>  

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Commissioning </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>comm/tambahcomm">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>comm/lihatcomm">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li>  

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Sea Trial </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>sea/tambahsea">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>sea/lihatsea">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li>  

                    <li>
                        <a href="#" class="menu-dropdown">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Delivery </span>

                            <i class="menu-expand"></i>
                        </a>

                        <ul class="submenu">
                            <li>
                                <a href="<?php echo base_url(); ?>delivery/tambahdelivery">
                                    <span class="menu-text">Tambah Data</span>
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo base_url(); ?>delivery/lihatdelivery">
                                    <span class="menu-text">Lihat List Data</span>
                                </a>
                            </li>                            
                            
                        </ul>
                    </li> 
                    <li>
                        <a href="<?php echo base_url(); ?>home/search">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Logic Search </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>home/reminder">
                            <i class="menu-icon fa fa-pencil-square-o"></i>
                            <span class="menu-text"> Reminder </span>
                        </a>
                    </li>                     
                    <!--Widgets-->                    
                    
                </ul>
                <!-- /Sidebar Menu -->
            </div>